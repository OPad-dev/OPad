%TF.GenerationSoftware,osuPad he_board.py*%
%TF.CreationDate,2026-09-20T14:07:57+02:00*%
%TF.ProjectId,he_input_v1,e8072571-6437-4807-8257-e80725716437,V1.0*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,SolderMask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
%G04 Created by osuPad he_board.py on 2026-09-20T14:07:57+02:00*%
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
